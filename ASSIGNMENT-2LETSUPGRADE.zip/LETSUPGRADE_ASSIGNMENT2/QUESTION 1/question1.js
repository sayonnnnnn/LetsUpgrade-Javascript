function changeToSuperman(){
	const image = document.getElementById('Batman');
	const superman = "https://cdn.theatlantic.com/thumbor/xuePShEYRyEQec_THgWcYFhYLnw=/540x0:2340x1800/500x500/media/img/mt/2016/01/superman/original.jpg";
	image.src = superman;	
	image.id = "Superman"; //CHANGES THE ID TO 'SUPERMAN'
}
function changeToWW(){
	const currentImage = document.getElementById('Superman');
	const wonderWoman = "https://i.insider.com/5ded5c4e79d757035d26ce62?width=1100&format=jpeg&auto=webp";
	currentImage.src = wonderWoman;
	currentImage.id = "Wonder Woman";
}
function changeToBatman(){
	const img = document.getElementById('Wonder Woman');
	const Bat = "https://image.cnbcfm.com/api/v1/image/105814861-1553608877209ben-affleck-batman-1.jpg?v=1553609938&w=1600&h=900";
	img.src = Bat;
	img.id = "Batman";
}