let justiceLeague = [
{
	name: "Bruce Wayne",
	age: 45,
	country: "USA",
	hobbies: ["Fighting Crime", "Maintaining playboy personality", "Meta-human research", "Making kryptonite weapons", "Exercising"]
},
{
	name: "Clark Kent",
	age: 38,
	country: "USA",
	hobbies: ["Fighting Crime", "Journalism", "Saving people", "Behaving like a normal human being", "Visiting Kansas"]
},
{
	name: "Diana Prince",
	age: 105,
	country: "Themiscyra",
	hobbies: ["Fighting Crime", "Making anti-patriarchy remarks", "Mastering her hebrew english accent", "Being strong and beautiful"]
},
{
	name: "Barry Allen",
	age: 26,
	country: "USA",
	hobbies: ["Fighting Crime", "Altering time", "Running", "Research in Star Labs", "Eating junk food", "Annoying fellow JL members"]
},
{
	name: "Arthur Curry",
	age: 36,
	country: "USA",
	hobbies: ["Fighting Crime in the 7 Oceans", "Swimming", "Mastering the TRIDENT", "Being a king"]
},
{
	name: "Hal Jordan",
	age: 29,
	country: "USA",
	hobbies: ["Fighting extra-terrestrial villains", "Leading the Green Lantern Corp", "Abusing Batman", "Mastering the Green Lantern Ring"]
}
]

function displayJusticeLeague(){
	justiceLeague.forEach(function (JL){
		console.log(JL);
		console.log('\n');
	});
}

displayJusticeLeague();
