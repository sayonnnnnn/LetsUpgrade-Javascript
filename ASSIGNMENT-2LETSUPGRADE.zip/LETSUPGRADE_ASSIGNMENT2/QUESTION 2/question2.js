/*
Question 2
Create a webpage containing two input fields and a button. 

A. Write something in the first input

 B. On click of the button, the content of input one should be copied in the second input
 */ 

function displayInput1(){
	const txt = document.getElementById("input1");
	let placeholder2 = txt.value;
	const txt2 = document.getElementById("input2");
	txt2.placeholder = placeholder2;
}