let employees = [
  {
    name: "Homelander",
    age: 34,
    city: "Washington DC",
    salary: "$200000"
  },
  {
    name: "Starlight",
    age:24,
    city:"Queens",
    salary:"$100000"
  },
  {
    name:"A-Train",
    age:28,
    city:"New York",
    salary:"$150000"
  },
  {
    name:"Queen Maeve",
    age:31,
    city:"Cincinnati",
    salary:"$200000"
  }
];

function display(emp) {
  let tabledata = "";

  emp.forEach(function (employee, index) {
    let currentrow = `<tr>
    <td>${index + 1}</td>
    <td>${employee.name}</td>
    <td>${employee.age}</td>
    <td>${employee.planet}</td>
    <td>${employee.height}</td>
    <td>
    <button onclick='deleteEmployee(${index})'>delete</button>
    <button onclick='showModal(${index})'>update</button>
    </td>
    </tr>`;

    tabledata += currentrow;

  });
  document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
  //   document.getElementById("tdata").innerHTML = tabledata;
}

display(employees);

function searchByName() {
  let searchValue = document.getElementById("searchName").value;

  let newdata = employees.filter(function (employee) {
    return (
      employee.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}

function deleteEmployee(index) {
  employees.splice(index, 1);
  display(employees);
}

function showModal(index) {
  let modal = document.getElementsByClassName("modal")[0];
  modal.style.display = "block";

  copySuperhero(index);
}

function hideModal(event) {
  if (event.target.className == "modal") {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none";
  }
}