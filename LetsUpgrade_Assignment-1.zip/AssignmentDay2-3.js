let string_array = ["Computer Science","Mechanical","Electronics","Mechatronics","Electrical","Agriculture"];
let pos=0;
var ele = window.prompt("Please enter the element to find it's location: ");
eleLower = ele.toLowerCase()
for (var i=0;i<string_array.length;i++){

	if(string_array[i].toLowerCase()==eleLower){
		pos=i+1;
	}
}
if(pos!=0){
console.log("The element "+ele+" is present at the "+pos+"position in the array!");
}else{
	console.log("The element "+ele+" is NOT AVAILABLE in the array of strings!!");
}