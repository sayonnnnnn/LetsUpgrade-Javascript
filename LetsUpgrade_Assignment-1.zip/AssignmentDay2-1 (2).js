let string = "Computer Science Engineering";
let pos=0;
var char = window.prompt("Please enter the character to find it's location: ");
for(var i=0;i<string.length;i++){
	if (string[i]==char){
		pos=i+1;
	}
//console.log("The position where "+char+" is found is at the "+pos+"th place!");
}
if (pos==0){
	console.log(char+" character is not vailable in the string!");
}else{
console.log("The position where "+char+" is found is at the "+pos+"th place!");
}