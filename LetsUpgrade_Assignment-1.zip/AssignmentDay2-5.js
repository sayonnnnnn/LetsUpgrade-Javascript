let numArray = [23, 56, 178, 99, 12, 5, 78];
let charArray = ["Computer Science","Mechanical","Electronics","Mechatronics","Electrical","Agriculture"];
var choice = window.prompt("Please enter 1 to work upon the numerical array \n Please enter 2 to work upon the string array \n Please enter your choice: ");
//do{
	if (choice==1){
		for( var i=numArray.length;i>0;i--){
			console.log(numArray[i]+'\t');
		}
	}
	if (choice==2){
		for(var i=charArray.length-1;i>=0;i--){
			console.log(charArray[i]+'\t');
		}
	}
//}while(choice<3);