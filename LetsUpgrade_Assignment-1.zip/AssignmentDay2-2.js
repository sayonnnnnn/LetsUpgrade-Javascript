var minutes = window.prompt("Enter the minutes to convert then=m into seconds");
console.log(minutes+" minutes are "+minutes*60+" seconds");