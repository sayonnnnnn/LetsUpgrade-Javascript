let string_array = ["Computer Science","Mechanical","Electronics","Mechatronics","Electrical","Agriculture"];
for(var i=0;i<string_array.length;i++){
	if(string_array[i].includes('a') || string_array[i].includes('A')){
		console.log(string_array[i]+"\n");
	}
}